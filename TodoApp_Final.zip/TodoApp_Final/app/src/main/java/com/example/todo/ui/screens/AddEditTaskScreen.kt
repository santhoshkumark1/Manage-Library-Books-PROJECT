package com.example.todo.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.todo.data.Priority
import com.example.todo.data.TaskViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTaskScreen(taskId: Long?, onDone: () -> Unit, vm: TaskViewModel = viewModel()) {
    val scope = rememberCoroutineScope()

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf(Priority.MEDIUM) }
    var dueDate by remember { mutableStateOf<String?>(null) }
    var category by remember { mutableStateOf("") }

    LaunchedEffect(taskId) {
        if (taskId != null) {
            vm.getTask(taskId)?.let { t ->
                title = t.title
                description = t.description
                priority = t.priority
                dueDate = t.dueDate
                category = t.category ?: ""
            }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text(if (taskId == null) "Add Task" else "Edit Task") }) }) { inner ->
        Column(Modifier.padding(inner).padding(16.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text("Priority")
            Row {
                Priority.values().forEach { p ->
                    FilterChip(selected = p == priority, onClick = { priority = p }, label = { Text(p.name) })
                    Spacer(Modifier.width(8.dp))
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = dueDate ?: "", onValueChange = { dueDate = it.ifBlank { null } }, label = { Text("Due Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category (optional)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                scope.launch {
                    vm.addOrUpdate(taskId, title, description, priority, dueDate, category.ifBlank { null })
                    onDone()
                }
            }, enabled = title.isNotBlank()) { Text(if (taskId == null) "Save" else "Update") }
        }
    }
}
