package com.example.todo.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UiState(val tasks: List<Task> = emptyList())

class TaskViewModel(app: Application): AndroidViewModel(app) {
    private val dao = TaskDatabase.get(app).taskDao()

    val state: StateFlow<UiState> = dao.observeAll()
        .map { UiState(tasks = it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState())

    fun addOrUpdate(id: Long? = null, title: String, description: String, priority: Priority, dueDate: String?, category: String?) =
        viewModelScope.launch {
            val task = Task(
                id = id ?: 0,
                title = title.trim(),
                description = description.trim(),
                priority = priority,
                dueDate = dueDate,
                category = category?.trim().takeUnless { it.isNullOrBlank() }
            )
            dao.upsert(task)
        }

    fun toggleCompleted(task: Task) = viewModelScope.launch { dao.upsert(task.copy(completed = !task.completed)) }
    fun delete(task: Task) = viewModelScope.launch { dao.delete(task) }
    suspend fun getTask(id: Long) = dao.getById(id)
}
