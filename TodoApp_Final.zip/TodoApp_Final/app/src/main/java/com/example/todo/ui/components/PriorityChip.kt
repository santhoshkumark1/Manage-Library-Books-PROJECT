package com.example.todo.ui.components

import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.todo.data.Priority

@Composable
fun PriorityChip(priority: Priority) {
    AssistChip(onClick = { }, enabled = false, label = { Text(priority.name) }, colors = AssistChipDefaults.assistChipColors())
}
