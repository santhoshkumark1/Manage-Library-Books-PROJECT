package com.example.todo.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.todo.ui.screens.AddEditTaskScreen
import com.example.todo.ui.screens.TaskListScreen

object Routes { const val LIST = "list"; const val ADD_EDIT = "addEdit" }

@Composable
fun AppNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.LIST) {
        composable(Routes.LIST) {
            TaskListScreen(onAddNew = { navController.navigate(Routes.ADD_EDIT) }, onEdit = { id -> navController.navigate("${Routes.ADD_EDIT}?id=$id") })
        }
        composable("${Routes.ADD_EDIT}?id={id}") { backStackEntry ->
            val idArg = backStackEntry.arguments?.getString("id")?.toLongOrNull()
            AddEditTaskScreen(taskId = idArg, onDone = { navController.popBackStack() })
        }
        composable(Routes.ADD_EDIT) { AddEditTaskScreen(taskId = null, onDone = { navController.popBackStack() }) }
    }
}
