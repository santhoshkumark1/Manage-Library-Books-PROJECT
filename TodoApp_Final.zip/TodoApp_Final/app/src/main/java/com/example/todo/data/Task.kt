package com.example.todo.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val completed: Boolean = false,
    val priority: Priority = Priority.MEDIUM,
    val dueDate: String? = null,
    val category: String? = null
)

enum class Priority { HIGH, MEDIUM, LOW }
