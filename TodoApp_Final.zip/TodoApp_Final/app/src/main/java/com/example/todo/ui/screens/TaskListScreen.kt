package com.example.todo.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.todo.data.Task
import com.example.todo.data.TaskViewModel
import com.example.todo.ui.components.PriorityChip

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskListScreen(onAddNew: () -> Unit, onEdit: (Long) -> Unit, vm: TaskViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    Scaffold(
        topBar = { TopAppBar(title = { Text("To-Do") }) },
        floatingActionButton = { FloatingActionButton(onClick = onAddNew) { Text("+") } }
    ) { inner ->
        LazyColumn(Modifier.padding(inner).fillMaxSize().padding(16.dp)) {
            items(state.tasks, key = { it.id }) { task ->
                TaskRow(task, onToggle = { vm.toggleCompleted(task) }, onEdit = { onEdit(task.id) }, onDelete = { vm.delete(task) })
                Divider(Modifier.padding(vertical = 8.dp))
            }
        }
    }
}

@Composable
private fun TaskRow(task: Task, onToggle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Row(Modifier.weight(1f)) {
            Checkbox(checked = task.completed, onCheckedChange = { onToggle() })
            Column(Modifier.padding(start = 8.dp).weight(1f)) {
                Text(text = task.title, style = MaterialTheme.typography.titleMedium, textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None)
                if (task.description.isNotBlank()) {
                    Text(text = task.description, style = MaterialTheme.typography.bodyMedium, textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None)
                }
                Row(Modifier.padding(top = 4.dp)) {
                    PriorityChip(priority = task.priority)
                    if (task.dueDate != null) {
                        Spacer(Modifier.width(8.dp))
                        AssistChip(onClick = {}, enabled = false, label = { Text("Due: ${task.dueDate}") })
                    }
                    if (!task.category.isNullOrBlank()) {
                        Spacer(Modifier.width(8.dp))
                        AssistChip(onClick = {}, enabled = false, label = { Text(task.category!!) })
                    }
                }
            }
        }
        Row {
            TextButton(onClick = onEdit) { Text("Edit") }
            TextButton(onClick = onDelete) { Text("Delete") }
        }
    }
}
