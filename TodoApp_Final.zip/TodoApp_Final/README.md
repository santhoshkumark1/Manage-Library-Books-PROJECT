# TodoApp
Open in Android Studio, let Gradle sync, run on emulator or device, or build APK via Build → Build APK(s).
