# Manage Library Books (CodeIgniter 4 + Docker)

CRUD application for managing library books with optional cover images.

## Stack
- PHP 8.2 + Apache
- CodeIgniter 4
- MySQL 8
- phpMyAdmin
- Docker Compose

## Setup
```bash
git clone <repo-url>
cd Manage-Library-Books
docker compose up -d
cd app
cp env .env
php spark key:generate
# edit .env → set DB host=db, database=library, user=app, pass=app
php spark migrate
php spark db:seed BookSeeder   # optional demo data
```

- App → http://localhost:8080  
- phpMyAdmin → http://localhost:9090  

## Features
- Add, view, update, delete book records
- Required fields: title, author, year
- Optional: cover image upload
- Validations + flash messages
- Bootstrap 5 UI

## Teardown
```bash
docker compose down -v
```
