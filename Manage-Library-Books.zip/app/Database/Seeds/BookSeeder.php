<?php
namespace App\Database\Seeds;
use CodeIgniter\Database\Seeder;

class BookSeeder extends Seeder {
  public function run() {
    $this->db->table('books')->insertBatch([
      ['title'=>'Clean Code','author'=>'Robert C. Martin','genre'=>'Software','publication_year'=>2008],
      ['title'=>'Pragmatic Programmer','author'=>'Andrew Hunt','genre'=>'Software','publication_year'=>1999],
    ]);
  }
}
