<?php
namespace App\Controllers;
use App\Models\BookModel;

class Books extends BaseController {
  public function index() {
    $books=(new BookModel())->orderBy('id','desc')->findAll();
    return view('books/index',['books'=>$books]);
  }
  public function create() {
    return view('books/form',['action'=>site_url('books/store'),'button'=>'Save']);
  }
  public function store() {
    $m=new BookModel();
    if(!$this->validate($m->validationRules,$m->validationMessages)){
      return redirect()->back()->withInput()->with('errors',$this->validator->getErrors());
    }
    $file=$this->request->getFile('cover'); $coverPath=null;
    if($file && $file->isValid() && !$file->hasMoved()){
      $name=$file->getRandomName(); $file->move(WRITEPATH.'uploads',$name);
      $coverPath='writable/uploads/'.$name;
    }
    $m->insert([
      'title'=>$this->request->getPost('title'),
      'author'=>$this->request->getPost('author'),
      'genre'=>$this->request->getPost('genre'),
      'publication_year'=>(int)$this->request->getPost('publication_year'),
      'cover_path'=>$coverPath,
    ]);
    return redirect()->to(site_url('books'))->with('message','Book added.');
  }
  public function edit($id) {
    $b=(new BookModel())->find($id);
    if(!$b) return redirect()->to(site_url('books'));
    return view('books/form',['book'=>$b,'action'=>site_url('books/update/'.$id),'button'=>'Update']);
  }
  public function update($id) {
    $m=new BookModel();
    if(!$this->validate($m->validationRules,$m->validationMessages)){
      return redirect()->back()->withInput()->with('errors',$this->validator->getErrors());
    }
    $data=[
      'title'=>$this->request->getPost('title'),
      'author'=>$this->request->getPost('author'),
      'genre'=>$this->request->getPost('genre'),
      'publication_year'=>(int)$this->request->getPost('publication_year'),
    ];
    $file=$this->request->getFile('cover');
    if($file && $file->isValid() && !$file->hasMoved() && $file->getSize()>0){
      $name=$file->getRandomName(); $file->move(WRITEPATH.'uploads',$name);
      $data['cover_path']='writable/uploads/'.$name;
    }
    $m->update($id,$data);
    return redirect()->to(site_url('books'))->with('message','Book updated.');
  }
  public function delete($id) {
    $m=new BookModel(); $row=$m->find($id);
    if($row && !empty($row['cover_path']) && is_file(ROOTPATH.$row['cover_path'])) @unlink(ROOTPATH.$row['cover_path']);
    $m->delete($id);
    return redirect()->to(site_url('books'))->with('message','Book deleted.');
  }
}
