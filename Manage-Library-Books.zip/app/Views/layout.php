<!doctype html><html><head>
<meta charset="utf-8"><title>Manage Library Books</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head><body class="p-4"><div class="container">
<h1 class="mb-4">Manage Library Books</h1>
<?php if(session()->getFlashdata('message')): ?>
<div class="alert alert-success"><?= esc(session()->getFlashdata('message')) ?></div>
<?php endif ?>
<?php if(session()->getFlashdata('errors')): ?>
<div class="alert alert-danger"><ul class="mb-0">
<?php foreach(session()->getFlashdata('errors') as $e): ?><li><?= esc($e) ?></li><?php endforeach ?>
</ul></div>
<?php endif ?>
<?= $this->renderSection('content') ?>
</div></body></html>
