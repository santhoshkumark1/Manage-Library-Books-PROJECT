<?= $this->extend('layout') ?><?= $this->section('content') ?>
<form action="<?= esc($action) ?>" method="post" enctype="multipart/form-data" class="row g-3">
  <div class="col-md-6"><label class="form-label">Title*</label>
    <input name="title" class="form-control" value="<?= old('title',$book['title']??'') ?>"></div>
  <div class="col-md-6"><label class="form-label">Author*</label>
    <input name="author" class="form-control" value="<?= old('author',$book['author']??'') ?>"></div>
  <div class="col-md-6"><label class="form-label">Genre</label>
    <input name="genre" class="form-control" value="<?= old('genre',$book['genre']??'') ?>"></div>
  <div class="col-md-6"><label class="form-label">Year*</label>
    <input name="publication_year" type="number" class="form-control" value="<?= old('publication_year',$book['publication_year']??'') ?>"></div>
  <div class="col-md-6"><label class="form-label">Cover (optional)</label>
    <input name="cover" type="file" class="form-control">
    <?php if(!empty($book['cover_path'])): ?><small>Current: <?= esc($book['cover_path']) ?></small><?php endif ?>
  </div>
  <div class="col-12">
    <button class="btn btn-primary"><?= esc($button) ?></button>
    <a class="btn btn-light" href="<?= site_url('books') ?>">Cancel</a>
  </div>
</form>
<?= $this->endSection() ?>
