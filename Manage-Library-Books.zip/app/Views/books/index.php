<?= $this->extend('layout') ?><?= $this->section('content') ?>
<div class="mb-3"><a class="btn btn-primary" href="<?= site_url('books/create') ?>">Add Book</a></div>
<table class="table table-striped align-middle"><thead>
<tr><th>#</th><th>Title</th><th>Author</th><th>Genre</th><th>Year</th><th>Cover</th><th>Actions</th></tr>
</thead><tbody>
<?php foreach($books as $b): ?>
<tr>
  <td><?= esc($b['id']) ?></td>
  <td><?= esc($b['title']) ?></td>
  <td><?= esc($b['author']) ?></td>
  <td><?= esc($b['genre']) ?></td>
  <td><?= esc($b['publication_year']) ?></td>
  <td>
    <?php if(!empty($b['cover_path'])): ?>
      <img src="/<?= esc($b['cover_path']) ?>" alt="cover" style="height:60px">
    <?php else: ?><span class="text-muted">No image</span><?php endif ?>
  </td>
  <td>
    <a class="btn btn-sm btn-secondary" href="<?= site_url('books/edit/'.$b['id']) ?>">Edit</a>
    <a class="btn btn-sm btn-danger" onclick="return confirm('Delete this book?')" href="<?= site_url('books/delete/'.$b['id']) ?>">Delete</a>
  </td>
</tr>
<?php endforeach ?>
</tbody></table>
<?= $this->endSection() ?>
