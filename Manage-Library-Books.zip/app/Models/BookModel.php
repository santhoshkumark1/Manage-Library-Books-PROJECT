<?php
namespace App\Models;
use CodeIgniter\Model;

class BookModel extends Model {
  protected $table='books';
  protected $primaryKey='id';
  protected $allowedFields=['title','author','genre','publication_year','cover_path'];
  protected $useTimestamps=true;
  protected $validationRules=[
    'title'=>'required|min_length[2]',
    'author'=>'required|min_length[2]',
    'publication_year'=>'required|integer|greater_than_equal_to[0]|less_than_equal_to['.date('Y').']',
  ];
  protected $validationMessages=[
    'title'=>['required'=>'Title is required.'],
    'author'=>['required'=>'Author is required.'],
    'publication_year'=>['required'=>'Year is required.','integer'=>'Year must be a number.'],
  ];
}
